// Truva - Wizard Designer Chat Interface

document.addEventListener('DOMContentLoaded', () => {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const suggestions = document.getElementById('copilotkit-footer');
    const agentLanding = document.getElementById('agent-landing');
    const landingFeatured = document.getElementById('landing-featured');
    const attachButton = document.getElementById('attach-button');
    const fileInput = document.getElementById('file-input');
    const voiceButton = document.getElementById('voice-button');
    const stopButton = document.getElementById('stop-button');
    const generatedNumberEl = document.getElementById('generated-number');
    const inputContainer = document.querySelector('.input-container');
    const personaAvatarImg = document.getElementById('persona-avatar-img');
    const AVATAR_STORAGE_KEY = 'assistantAvatar';

    // Theme toggle removed per revert request

    // WebSocket setup for bidirectional streaming
    let ws = null;
    let wsReady = false;
    const wsPending = new Map();
    let wsCounter = 0;

    function initWebSocket() {
        try {
            const wsUrl = (window.location.origin.replace('http', 'ws')) + '/api/copilot/ws';
            ws = new WebSocket(wsUrl);
            ws.addEventListener('open', () => {
                wsReady = true;
            });
            ws.addEventListener('close', () => {
                wsReady = false;
            });
            ws.addEventListener('error', () => {
                wsReady = false;
            });
            ws.addEventListener('message', (event) => {
                try {
                    const payload = JSON.parse(event.data);
                    const id = payload && payload.id ? String(payload.id) : null;
                    const pending = id ? wsPending.get(id) : null;
                    const text = payload.response || payload.chunk || '';
                    const isDone = payload.done === true || typeof payload.response === 'string';
                    if (pending && pending.streamingDiv) {
                        // Append chunk or finalize
                        if (text) {
                            pending.streamedText += text;
                            pending.streamingDiv.textContent = pending.streamedText;
                        }
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                        if (isDone) {
                            const elapsedMs = pending.startTime ? (Date.now() - pending.startTime) : null;
                            addMessageToChat('assistant', pending.streamedText || text || '');
                            // remove transient container
                            if (pending.streamingContainer && pending.streamingContainer.parentElement) {
                                pending.streamingContainer.remove();
                            }
                            // update generated badge
                            if (generatedNumberEl) {
                                const badge = generatedNumberEl.querySelector('.badge');
                                if (badge) {
                                    badge.textContent = `Generated in ${elapsedMs ? formatElapsed(elapsedMs) : '—'}`;
                                }
                            }
                            wsPending.delete(id);
                        }
                    } else {
                        // No pending; just append assistant message
                        addMessageToChat('assistant', text || '');
                    }
                } catch (e) {
                    // ignore malformed payloads
                }
            });
        } catch (e) { /* no-op */ }
    }
    // initWebSocket disabled

    function sendMessageViaWS(message) { return false; }

    // Initialize chat history
    let chatHistory = [];
    let lastUserMessage = '';
    let genStartTime = null;
    let recognizing = false;
    let recognition = null;
    let voiceAccumulated = '';
    let baseInputBeforeVoice = '';
    let currentAbortController = null;
    let currentThinkingTimer = null;

    // Auto-resize textarea and toggle send availability
    function adjustInputState() {
        try {
            // Auto-resize
            userInput.style.height = 'auto';
            const h = Math.min(userInput.scrollHeight, 200);
            userInput.style.height = h + 'px';
        } catch (e) { /* no-op */ }
        // Enable send only if there is content
        sendButton.disabled = !userInput.value.trim();
        // Footer removed; no reposition needed
    }
    if (userInput) {
        userInput.addEventListener('input', adjustInputState);
        // Initial state
        adjustInputState();
    }

    // Footer positioning: keep footer above the input container
    function updateFooterPosition() {
        try {
            const footer = document.getElementById('copilotkit-footer');
            const ic = document.querySelector('.input-container');
            if (!footer || !ic) return;
            // If footer is embedded inside the input container, don't reposition with bottom
            if (footer.closest('.input-container')) {
                footer.style.bottom = 'auto';
                return;
            }
            const inputHeight = ic.offsetHeight || 0;
            const bottom = Math.max(56, inputHeight + 24);
            footer.style.bottom = bottom + 'px';
        } catch (e) { /* no-op */ }
    }

    // Hide CopilotKit footer with animation
    function hideCopilotFooter() {
        if (!suggestions) return;
        suggestions.classList.add('footer-hidden');
    }

    // Assistant avatar persistence
    function loadAssistantAvatar() {
        try {
            const saved = localStorage.getItem(AVATAR_STORAGE_KEY);
            if (saved && personaAvatarImg) {
                personaAvatarImg.src = saved;
            }
        } catch (e) { /* no-op */ }
    }

    // Bind avatar upload controls
    // Upload UI removed per request; keep persistence if a value exists

    // Initial load adjustments
    loadAssistantAvatar();
    // Agent selection + landing overlay
    let selectedAgent = null;
    function setSuggestionsForAgent(agent) {
        const footer = document.getElementById('copilotkit-footer');
        if (!footer) return;
        const track = footer.querySelector('.footer-carousel-track');
        if (!track) return;
        const groups = {
            agentic: [
                { text: 'Analyze Instagram → brand direction', msg: 'Analyze my Instagram @influencer and suggest a brand direction' },
                { text: 'Pick a brand name + check domains', msg: 'Help me choose a brand name and check domain availability' },
                { text: 'Generate logo ideas', msg: 'Generate three logo ideas for my brand' },
                { text: 'Recommend products to sell', msg: 'Recommend products to sell based on my brand' },
                { text: 'Purple palette with roles', msg: 'Create a purple-themed palette and usage roles' },
            ],
            schedule: [
                { text: 'Check time slots', msg: 'What slots are available next week?' },
                { text: 'Book a call', msg: 'Book a call next week Tuesday 3pm' },
                { text: 'Reschedule meeting', msg: 'Reschedule my meeting to Friday 10am' },
                { text: 'Cancel meeting', msg: 'Cancel my meeting scheduled with Codey' },
            ],
            default: [
                { text: 'Analyze Instagram → brand direction', msg: 'Analyze my Instagram @influencer and suggest a brand direction' },
                { text: 'Pick a brand name + check domains', msg: 'Help me choose a brand name and check domain availability' },
                { text: 'Suggest color palette (HEX)', msg: 'Suggest a color palette with HEX codes for a wellness brand' },
                { text: 'Generate logo ideas', msg: 'Generate three logo ideas for my brand' },
                { text: 'Recommend products to sell', msg: 'Recommend products to sell based on my brand' },
                { text: 'Analyze competitors → differentiation', msg: 'Analyze competitors and propose differentiation' },
                { text: 'Estimate profit', msg: 'Estimate profit if cost is 12, price is 29, units 120' },
                { text: 'Book a call', msg: 'Book a call next week Tuesday 3pm' },
                { text: 'Purple palette with roles', msg: 'Create a purple-themed palette and usage roles' },
            ]
        };
        const items = groups[agent] || groups.default;
        track.innerHTML = '';
        items.forEach(item => {
            const btn = document.createElement('button');
            btn.className = 'suggestion-chip';
            btn.setAttribute('data-msg', item.msg);
            btn.textContent = item.text;
            track.appendChild(btn);
        });
        const clearBtn = document.createElement('button');
        clearBtn.className = 'suggestion-chip danger';
        clearBtn.id = 'clear-chat';
        clearBtn.textContent = 'Clear chat';
        track.appendChild(clearBtn);
    }
    // Reveal the main chat UI once the user makes a selection
    function revealApp() {
        try {
            document.getElementById('chat-messages')?.classList.remove('hidden');
            document.getElementById('copilotkit-footer')?.classList.remove('hidden');
            document.getElementById('generated-number')?.classList.remove('hidden');
            document.querySelector('.input-container')?.classList.remove('hidden');
        } catch (_) { /* no-op */ }
        // Ensure suggestions have content even if no agent selected yet
        try {
            setSuggestionsForAgent(selectedAgent || 'default');
        } catch (e) { /* no-op */ }
    }

    function applyAgent(agent) {
        selectedAgent = agent;
        setSuggestionsForAgent(agent);
        // Store in URL for clean navigation
        try {
            const url = new URL(window.location.href);
            if (agent) url.searchParams.set('agent', agent);
            else url.searchParams.delete('agent');
            window.history.replaceState({}, '', url);
        } catch (e) { /* no-op */ }
        // Hide landing overlay when an agent is chosen and reveal chat UI
        if (agentLanding) agentLanding.classList.add('hidden');
        revealApp();
    }
    // Initialize from URL if provided
    try {
        const params = new URLSearchParams(window.location.search);
        const initialAgent = params.get('agent');
        if (initialAgent) {
            applyAgent(initialAgent);
        }
    } catch (e) { /* no-op */ }
    // Bind landing chips
    document.querySelectorAll('.agent-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const agent = chip.getAttribute('data-agent');
            applyAgent(agent);
        });
    });
    if (landingFeatured) {
        landingFeatured.addEventListener('click', () => {
            if (agentLanding) agentLanding.classList.add('hidden');
            revealApp();
            userInput.value = landingFeatured.getAttribute('data-msg') || 'I want to build my brand';
            adjustInputState();
            sendMessage();
        });
    }
    updateFooterPosition();
    window.addEventListener('resize', updateFooterPosition);
    // Update time-ago labels periodically
    setInterval(updateAllTimeAgo, 60000);


    // Function to extract image paths from content
    function extractImagePaths(content) {
        if (typeof content !== 'string') return { text: content, images: [] };
        
        // Match image paths and LOGO IDs
        const imageRegex = /(\/outputs\/logos\/[^\s"'()<>]+\.(?:png|jpg|jpeg|svg|webp)|LOGO_[a-f0-9]+)/g;
        const images = [];
        let match;
        
        // Find all matches
        while ((match = imageRegex.exec(content)) !== null) {
            images.push(match[0]);
        }
        
        console.log("Found images:", images);
        
        // Remove image paths from the text while preserving line breaks
        let text = content;
        images.forEach(img => {
            text = text.replace(img, '');
        });

        // Normalize whitespace but PRESERVE newlines for markdown parsing
        text = text
            .replace(/\r\n/g, '\n')           // normalize CRLF
            .replace(/[\t ]+/g, ' ')            // collapse tabs/spaces
            .replace(/[\t ]*\n[\t ]*/g, '\n') // trim around newlines
            .trim();
        
        return { text, images };
    }

    // Markdown-aware, HTML-safe rendering for better chatbot formatting
    function renderContentToHtml(text) {
        if (typeof text !== 'string' || !text) return '';
        // Escape HTML
        let escaped = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');

        // Preserve code blocks ```code```
        let html = escaped.replace(/```([\s\S]*?)```/g, (m, code) => {
            const restored = code.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
            return `<pre><code>${restored}</code></pre>`;
        });

        // Inline code `code`
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

        // Process lines for lists, headings, and tables
        const lines = html.split(/\n/g);
        let out = '';
        let inUl = false;
        let inOl = false;
        let tableBuffer = [];
        const closeLists = () => {
            if (inUl) { out += '</ul>'; inUl = false; }
            if (inOl) { out += '</ol>'; inOl = false; }
        };
        const isMdTableRow = (line) => /^\|.*\|$/.test(line);
        const isAlignRow = (cells) => cells.every(c => /^:?-{2,}:?$/.test(c));
        const flushTable = () => {
            if (tableBuffer.length === 0) return;
            const rows = tableBuffer.map(l => l.slice(1, -1).split('|').map(c => c.trim()));
            let header = null;
            let body = rows;
            if (rows.length >= 2 && isAlignRow(rows[1])) {
                header = rows[0];
                body = rows.slice(2);
            }
            out += '<table class="md-table">';
            if (header) {
                out += '<thead><tr>' + header.map(h => `<th>${h}</th>`).join('') + '</tr></thead>';
            }
            out += '<tbody>' + body.map(r => '<tr>' + r.map(c => `<td>${c}</td>`).join('') + '</tr>').join('') + '</tbody>';
            out += '</table>';
            tableBuffer = [];
        };
        let inPre = false;
        for (let raw of lines) {
            const line = raw.trim();
            if (!line) { continue; }
            if (line.includes('<pre><code')) { inPre = true; out += line; continue; }
            if (inPre) { out += line; if (line.includes('</code></pre>')) inPre = false; continue; }
            // Markdown tables
            if (isMdTableRow(line)) { tableBuffer.push(line); continue; }
            if (tableBuffer.length) { flushTable(); }
            // Unordered list items
            if (/^(?:[-*•])\s+/.test(line)) {
                if (!inUl) { closeLists(); out += '<ul>'; inUl = true; }
                const item = line.replace(/^(?:[-*])\s+/, '');
                const itemFmt = item.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
                out += `<li>${itemFmt}</li>`;
                continue;
            }
            // Ordered list items
            if (/^\d+[.)]\s+/.test(line)) {
                if (!inOl) { closeLists(); out += '<ol>'; inOl = true; }
                const item = line.replace(/^\d+[.)]\s+/, '');
                const itemFmt = item.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
                out += `<li>${itemFmt}</li>`;
                continue;
            }
            // Headings
            const hMatch = line.match(/^(#{1,6})\s+(.*)$/);
            if (hMatch) {
                closeLists();
                const level = hMatch[1].length;
                const text = hMatch[2];
                const fmt = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
                out += `<h${level}>${fmt}</h${level}>`;
                continue;
            }
            // Regular paragraph
            closeLists();
            const para = line.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
            out += `<p>${para}</p>`;
        }
        if (tableBuffer.length) { flushTable(); }
        closeLists();

        // Color palette fallback: convert name + HEX lines into a table with swatches
        try {
            const rawLines = text.split(/\n/g);
            const paletteRows = [];
            for (const l of rawLines) {
                const m = l.match(/^\s*(?:[-*]\s*)?(.*?)\s*(?:[:\-–])\s*(#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}))/);
                const m2 = m || l.match(/\b(#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}))\b/);
                if (m2) {
                    const name = (m && m[1] ? m[1].trim() : 'Color');
                    const hex = (m ? m[2] : m2[1]).toUpperCase();
                    paletteRows.push({ name, hex });
                }
            }
            const uniqueRows = [];
            const seen = new Set();
            for (const r of paletteRows) {
                const key = r.name + '|' + r.hex;
                if (!seen.has(key)) { seen.add(key); uniqueRows.push(r); }
            }
            if (uniqueRows.length >= 2 && !out.includes('<table')) {
                out += '<table class="md-table"><thead><tr><th>Color</th><th>HEX</th><th>Preview</th></tr></thead><tbody>' +
                    uniqueRows.map(r => `<tr><td>${r.name}</td><td>${r.hex}</td><td><span class="swatch" style="background:${r.hex}"></span></td></tr>`).join('') +
                    '</tbody></table>';
            }
        } catch (e) { /* no-op */ }

        return out;
    }

    // Build reasoning summary by extracting steps/bullets
    function buildReasoningSummary(text) {
        if (!text || typeof text !== 'string') return [];
        const lines = text.split(/\n|<br>/g).map(l => l.trim()).filter(Boolean);
        const steps = [];
        for (const l of lines) {
            if (/^(?:[-*•]|\d+[.)]|step\s*\d+[:.])/i.test(l)) {
                steps.push(l.replace(/^[-*•]\s*/, ''));
            }
        }
        // Fallback: take first 3 sentences as outline
        if (steps.length === 0) {
            const sentences = text.split(/(?<=[.!?])\s+/).slice(0, 3);
            sentences.forEach(s => {
                if (s && s.trim()) steps.push(s.trim());
            });
        }
        return steps.slice(0, 6);
    }

    // Formatting helpers
    function formatElapsed(ms) {
        if (ms == null) return '';
        if (ms < 1000) return `${ms} ms`;
        const s = (ms / 1000);
        if (s < 60) return `${s.toFixed(1)} s`;
        const m = Math.floor(s / 60);
        const rem = s % 60;
        return `${m}m ${rem.toFixed(0)}s`;
    }

    function formatElapsedNumeric(ms) {
        if (ms == null) return '';
        if (ms < 1000) return `${ms}`;
        const s = (ms / 1000);
        return s.toFixed(1);
    }

    // Relative time helper, e.g., "4 minutes ago"
    function formatTimeAgo(ts) {
        const now = Date.now();
        const diff = Math.max(0, now - ts);
        const sec = Math.floor(diff / 1000);
        if (sec < 5) return 'just now';
        if (sec < 60) return `${sec} seconds ago`;
        const min = Math.floor(sec / 60);
        if (min < 60) return `${min} minute${min === 1 ? '' : 's'} ago`;
        const hrs = Math.floor(min / 60);
        if (hrs < 24) return `${hrs} hour${hrs === 1 ? '' : 's'} ago`;
        const days = Math.floor(hrs / 24);
        return `${days} day${days === 1 ? '' : 's'} ago`;
    }

    function updateAllTimeAgo() {
        const nodes = document.querySelectorAll('.time-ago[data-timestamp]');
        nodes.forEach(n => {
            const ts = parseInt(n.getAttribute('data-timestamp'), 10);
            if (!isNaN(ts)) n.textContent = formatTimeAgo(ts);
        });
    }

    // Smooth typing animation with blinking caret
    function typeTextWithCaret(targetEl, rawText, opts = {}) {
        const speed = Math.max(8, Math.min(100, opts.speedMs || 16));
        const caret = document.createElement('span');
        caret.className = 'typing-caret';
        targetEl.appendChild(caret);

        let i = 0;
        function step() {
            if (i >= rawText.length) {
                caret.remove();
                if (typeof opts.onComplete === 'function') opts.onComplete();
                return;
            }
            const ch = rawText[i++];
            if (ch === '\n') {
                targetEl.insertBefore(document.createElement('br'), caret);
            } else {
                targetEl.insertBefore(document.createTextNode(ch), caret);
            }
            let delay = speed;
            if (/[.,!?]/.test(ch)) delay = speed * 3; // shorter pause on punctuation
            setTimeout(step, delay);
        }
        step();
    }

    // Per-word typing animation for assistant messages
    function typeTextByWord(targetEl, rawText, opts = {}) {
        const cssSpeed = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--typing-word-speed-ms').trim(), 10);
        const speed = Math.max(40, Math.min(800, opts.speedMs || (isNaN(cssSpeed) ? 120 : cssSpeed)));
        targetEl.innerHTML = '';
        const tokens = String(rawText).split(/(\s+)/); // keep whitespace tokens
        let t = 0;
        tokens.forEach(tok => {
            if (/^\s+$/.test(tok)) {
                targetEl.appendChild(document.createTextNode(tok));
            } else {
                const span = document.createElement('span');
                span.className = 'thinking-word'; // reuse smooth fade-in styles
                span.textContent = tok;
                targetEl.appendChild(span);
                setTimeout(() => span.classList.add('in'), t);
                t += /[.,!?]$/.test(tok) ? speed * 1.5 : speed; // slight pause on punctuation
            }
        });
        setTimeout(() => { if (typeof opts.onComplete === 'function') opts.onComplete(); }, t + 10);
    }

    // Per-word thinking animation for the loading indicator
    function playThinkingWords(targetEl, rawText, opts = {}) {
        const cssSpeed = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--thinking-speed-ms').trim(), 10);
        const speed = Math.max(20, Math.min(400, opts.speedMs || (isNaN(cssSpeed) ? 60 : cssSpeed)));
        targetEl.innerHTML = '';
        // Replace dynamic placeholder with a random status
        const statuses = ['thinking', 'generating', 'creating'];
        let text = String(rawText);
        if (text.includes('${condeyisthinking}')) {
            const pick = statuses[Math.floor(Math.random() * statuses.length)];
            text = text.replace('${condeyisthinking}', pick);
        }
        const words = String(text).split(/\s+/).filter(Boolean);
        words.forEach((w, idx) => {
            const span = document.createElement('span');
            span.className = 'thinking-word';
            span.textContent = w;
            targetEl.appendChild(span);
            if (idx < words.length - 1) targetEl.appendChild(document.createTextNode(' '));
            setTimeout(() => span.classList.add('in'), idx * speed);
        });
    }

    // Start dynamic thinking status rotation for the loading indicator
    function startThinkingStatusRotation(targetEl) {
        const speedMs = (() => {
            const cssSpeed = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--thinking-speed-ms').trim(), 10);
            return isNaN(cssSpeed) ? 60 : cssSpeed;
        })();
        // Initial render
        playThinkingWords(targetEl, 'Codey is ${condeyisthinking}...', { speedMs });
        const id = setInterval(() => {
            playThinkingWords(targetEl, 'Codey is ${condeyisthinking}...', { speedMs });
        }, Math.max(900, speedMs * 10));
        return id;
    }

    // Build message row; remove user avatar while preserving assistant avatar
    function buildMessageRow(role, inner) {
        const row = document.createElement('div');
        row.className = 'message-row ' + role;

        if (role === 'assistant') {
            const avatar = document.createElement('img');
            avatar.className = 'avatar assistant-avatar';
            avatar.alt = 'Codey Avatar';
            avatar.src = (personaAvatarImg && personaAvatarImg.src) ? personaAvatarImg.src : 'assets/female-2.webp';
            row.appendChild(avatar);
            row.appendChild(inner);
        } else {
            // For user messages, omit avatar for a cleaner look
            row.appendChild(inner);
        }
        return row;
    }

    // Add message to chat
    function addMessageToChat(role, content, options = {}) {
        // Row wrapper for consistent separators and padding
        const containerDiv = document.createElement('div');
        containerDiv.className = 'message-container';

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}-message`;
        
        if (role === 'assistant') {
            // For assistant messages, check for image paths
            const { text, images } = extractImagePaths(content);

            // Helper: append images (logos render after typing completes)
            const appendImages = () => {
                if (images && images.length > 0) {
                    images.forEach(imgPath => {
                        const imgContainer = document.createElement('div');
                        imgContainer.className = 'image-container';

                        if (imgPath.startsWith('LOGO_')) {
                            const logoId = imgPath.split('_')[1];
                            const possiblePaths = [
                                `/outputs/logos/${logoId}/Treeoflife_${logoId}_UserPrompt_1.png`,
                                `/outputs/logos/${logoId}/Treeoflife_${logoId}_UserPrompt_2.png`,
                                `/outputs/logos/1760590552/Treeoflife_${logoId}_UserPrompt_2.png`,
                                `/outputs/logos/1760590552/Treeoflife_${logoId}_UserPrompt_1.png`
                            ];
                            let imageLoaded = false;
                            possiblePaths.forEach(path => {
                                if (!imageLoaded) {
                                    const img = document.createElement('img');
                                    img.src = path;
                                    img.alt = 'Generated logo';
                                    img.className = 'response-image';
                                    img.style.maxWidth = '300px';
                                    img.loading = 'lazy';
                                    img.decoding = 'async';
                                    img.onload = () => { imageLoaded = true; };
                                    img.onerror = () => {
                                        img.style.display = 'none';
                                        console.error('Failed to load image:', path);
                                    };
                                    imgContainer.appendChild(img);
                                }
                            });
                            const fallbackText = document.createElement('p');
                            fallbackText.textContent = `[Logo ID: ${logoId}]`;
                            fallbackText.style.color = '#718096';
                            fallbackText.style.fontSize = '0.8rem';
                            imgContainer.appendChild(fallbackText);
                        } else {
                            const img = document.createElement('img');
                            img.src = imgPath;
                            img.alt = 'Generated image';
                            img.className = 'response-image';
                            img.loading = 'lazy';
                            img.decoding = 'async';
                            img.onerror = () => {
                                img.style.display = 'none';
                                const errorText = document.createElement('p');
                                errorText.textContent = `[Image could not be loaded: ${imgPath}]`;
                                errorText.style.color = '#e53e3e';
                                errorText.style.fontSize = '0.8rem';
                                imgContainer.appendChild(errorText);
                            };
                            imgContainer.appendChild(img);
                        }
                        messageDiv.appendChild(imgContainer);
                    });
                }
            };

            // Helper: meta footer
            const insertAssistantMeta = () => {
                const meta = document.createElement('div');
                meta.className = 'message-meta';
                if (options.elapsedMs != null) {
                    const timeEl = document.createElement('span');
                    timeEl.className = 'MuiTypography-root MuiTypography-caption shining-left css-z5ufvz';
                    timeEl.textContent = `Generated in ${formatElapsed(options.elapsedMs)}`;
                    meta.appendChild(timeEl);
                }
                const createdAt = Date.now();
                const agoEl = document.createElement('span');
                agoEl.className = 'time-ago';
                agoEl.setAttribute('data-timestamp', String(createdAt));
                agoEl.textContent = formatTimeAgo(createdAt);
                meta.appendChild(agoEl);
                const copyBtn = document.createElement('button');
                copyBtn.className = 'copy-btn';
                copyBtn.title = 'Copy';
                copyBtn.setAttribute('aria-label', 'Copy message');
                copyBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="component-iconify MuiBox-root css-1570kgy iconify iconify--solar" width="1em" height="1em" viewBox="0 0 24 24"><path fill="currentColor" d="M6.6 11.397c0-2.726 0-4.089.843-4.936c.844-.847 2.201-.847 4.917-.847h2.88c2.715 0 4.073 0 4.916.847c.844.847.844 2.21.844 4.936v4.82c0 2.726 0 4.089-.844 4.936c-.843.847-2.201.847-4.916.847h-2.88c-2.716 0-4.073 0-4.917-.847s-.843-2.21-.843-4.936z"></path><path fill="currentColor" d="M4.172 3.172C3 4.343 3 6.229 3 10v2c0 3.771 0 5.657 1.172 6.828c.617.618 1.433.91 2.62 1.048c-.192-.84-.192-1.996-.192-3.66v-4.819c0-2.726 0-4.089.843-4.936c.844-.847 2.201-.847 4.917-.847h2.88c1.652 0 2.8 0 3.638.19c-.138-1.193-.43-2.012-1.05-2.632C16.657 2 14.771 2 11 2S5.343 2 4.172 3.172" opacity=".5"></path></svg>';
                copyBtn.addEventListener('click', async () => {
                    try {
                        const textToCopy = messageDiv.innerText.trim();
                        await navigator.clipboard.writeText(textToCopy);
                        copyBtn.classList.add('copied');
                        setTimeout(() => copyBtn.classList.remove('copied'), 1200);
                    } catch (e) {
                        console.error('Copy failed', e);
                    }
                });
                meta.appendChild(copyBtn);
                messageDiv.appendChild(meta);
            };

            // If there is text, play typing animation, then insert images + meta
            if (text && text.trim() !== '') {
                const typed = document.createElement('div');
                typed.className = 'typed-text';
                messageDiv.appendChild(typed);
                typeTextByWord(typed, text, {
                    speedMs: (() => {
                        const cssSpeed = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--typing-word-speed-ms').trim(), 10);
                        return isNaN(cssSpeed) ? 90 : cssSpeed; // faster per-word animation
                    })(),
                    onComplete: () => {
                        typed.innerHTML = renderContentToHtml(text);
                        appendImages();
                        insertAssistantMeta();
                        updateAllTimeAgo();
                    }
                });
            } else {
                // No text; show images and meta immediately
                appendImages();
                insertAssistantMeta();
            }
        } else {
            // For user messages, render text with simple formatting
            const html = renderContentToHtml(content);
            messageDiv.insertAdjacentHTML('beforeend', html);
            if (options.images && options.images.length) {
                options.images.forEach(src => {
                    const imgContainer = document.createElement('div');
                    imgContainer.className = 'image-container';
                    const img = document.createElement('img');
                    img.src = src;
                    img.alt = 'Attachment';
                    img.className = 'response-image';
                    imgContainer.appendChild(img);
                    messageDiv.appendChild(imgContainer);
                });
            }

            // Meta footer: time ago + copy icon for user messages
            {
                const meta = document.createElement('div');
                meta.className = 'message-meta';
                const createdAt = Date.now();
                const agoEl = document.createElement('span');
                agoEl.className = 'time-ago';
                agoEl.setAttribute('data-timestamp', String(createdAt));
                agoEl.textContent = formatTimeAgo(createdAt);
                meta.appendChild(agoEl);
                const copyBtn = document.createElement('button');
                copyBtn.className = 'copy-btn';
                copyBtn.title = 'Copy';
                copyBtn.setAttribute('aria-label', 'Copy message');
                copyBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="component-iconify MuiBox-root css-1570kgy iconify iconify--solar" width="1em" height="1em" viewBox="0 0 24 24"><path fill="currentColor" d="M6.6 11.397c0-2.726 0-4.089.843-4.936c.844-.847 2.201-.847 4.917-.847h2.88c2.715 0 4.073 0 4.916.847c.844.847.844 2.21.844 4.936v4.82c0 2.726 0 4.089-.844 4.936c-.843.847-2.201.847-4.916.847h-2.88c-2.716 0-4.073 0-4.917-.847s-.843-2.21-.843-4.936z"></path><path fill="currentColor" d="M4.172 3.172C3 4.343 3 6.229 3 10v2c0 3.771 0 5.657 1.172 6.828c.617.618 1.433.91 2.62 1.048c-.192-.84-.192-1.996-.192-3.66v-4.819c0-2.726 0-4.089.843-4.936c.844-.847 2.201-.847 4.917-.847h2.88c1.652 0 2.8 0 3.638.19c-.138-1.193-.43-2.012-1.05-2.632C16.657 2 14.771 2 11 2S5.343 2 4.172 3.172" opacity=".5"></path></svg>';
                copyBtn.addEventListener('click', async () => {
                    try {
                        const textToCopy = messageDiv.innerText.trim();
                        await navigator.clipboard.writeText(textToCopy);
                        copyBtn.classList.add('copied');
                        setTimeout(() => copyBtn.classList.remove('copied'), 1200);
                    } catch (e) {
                        console.error('Copy failed', e);
                    }
                });
                meta.appendChild(copyBtn);
                messageDiv.appendChild(meta);
            }
        }
        
        const row = buildMessageRow(role, messageDiv);
        containerDiv.appendChild(row);
        chatMessages.appendChild(containerDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        containerDiv.scrollIntoView({ behavior: 'smooth', block: 'end' });
        
        // Update chat history (store created time for completeness)
        chatHistory.push({ role, content, elapsedMs: options.elapsedMs || null, createdAt: Date.now() });
        // Refresh time-ago labels immediately
        updateAllTimeAgo();
    }
    // Build CopilotKit-style messages payload from chatHistory
    function buildCopilotMessages() {
        try {
            return (chatHistory || []).map(m => ({ role: m.role, content: m.content }));
        } catch (e) {
            return [];
        }
    }

    // Stream CopilotKit chat via SSE-like response (POST + text/event-stream)
    async function streamCopilotChat(messages, onChunk) {
        try {
            const response = await fetch('/api/copilot/chat/stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ messages })
            });
            if (!response.ok) throw new Error(`Stream failed: ${response.status}`);
            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let done = false;
            let buffer = '';
            while (!done) {
                const { value, done: readerDone } = await reader.read();
                done = readerDone;
                if (value) {
                    buffer += decoder.decode(value, { stream: true });
                    const parts = buffer.split('\n\n');
                    // Keep last incomplete chunk in buffer
                    buffer = parts.pop() || '';
                    for (const part of parts) {
                        const lines = part.split('\n');
                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                try {
                                    const evt = JSON.parse(line.slice(6));
                                    if (evt && typeof evt.chunk === 'string') {
                                        onChunk(evt.chunk, !!evt.done);
                                    }
                                } catch (e) { /* ignore parse errors */ }
                            }
                        }
                    }
                }
            }
        } catch (e) {
            throw e;
        }
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;

        lastUserMessage = message;
        // Add user message to chat
        addMessageToChat('user', message);
        userInput.value = '';
        // Reset input state
        userInput.style.height = '';
        adjustInputState();

        // Add loading indicator
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message assistant-message loading';
        loadingDiv.textContent = '';
        // Show Stop while generating
        if (stopButton) {
            stopButton.style.display = 'inline-flex';
        }
        // Start dynamic thinking status rotation
        currentThinkingTimer = startThinkingStatusRotation(loadingDiv);
        loadingDiv.id = 'loading-indicator';
        const loadingContainer = document.createElement('div');
        loadingContainer.className = 'message-container';
        const loadingRow = buildMessageRow('assistant', loadingDiv);
        loadingContainer.appendChild(loadingRow);
        chatMessages.appendChild(loadingContainer);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        genStartTime = Date.now();

        try {
            // Enable immediate cancellation
            currentAbortController = new AbortController();
            const response = await fetch('/api/ask', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: message }),
                signal: currentAbortController.signal,
            });
            if (!response.ok) throw new Error(`API request failed with status ${response.status}`);
            const data = await response.json();
            // Remove loading indicator and its wrapper to avoid blank space
            const loadingIndicator = document.getElementById('loading-indicator');
            if (loadingIndicator) {
                const row = loadingIndicator.parentElement; // .message-row
                const container = row && row.parentElement;  // .message-container
                loadingIndicator.remove();
                if (container && container.classList && container.classList.contains('message-container')) {
                    container.remove();
                } else if (row && row.classList && row.classList.contains('message-row')) {
                    row.remove();
                }
            }
            const responseText = (data && data.response) ? data.response : 'No response received';
            const elapsedMs = genStartTime ? (Date.now() - genStartTime) : null;
            genStartTime = null;
            // Stop UI indicators
            if (currentThinkingTimer) { clearInterval(currentThinkingTimer); currentThinkingTimer = null; }
            currentAbortController = null;
            if (stopButton) { stopButton.style.display = 'none'; }
            addMessageToChat('assistant', responseText, { elapsedMs });
            if (generatedNumberEl) {
                const badge = generatedNumberEl.querySelector('.badge');
                if (badge) {
                    badge.textContent = `Generated in ${elapsedMs ? formatElapsed(elapsedMs) : '—'}`;
                }
            }
        } catch (error) {
            // Remove loading indicator and its wrapper to avoid blank space
            const loadingIndicator = document.getElementById('loading-indicator');
            if (loadingIndicator) {
                const row = loadingIndicator.parentElement; // .message-row
                const container = row && row.parentElement;  // .message-container
                loadingIndicator.remove();
                if (container && container.classList && container.classList.contains('message-container')) {
                    container.remove();
                } else if (row && row.classList && row.classList.contains('message-row')) {
                    row.remove();
                }
            }
            const elapsedMs = genStartTime ? (Date.now() - genStartTime) : null;
            genStartTime = null;
            // Stop UI indicators
            if (currentThinkingTimer) { clearInterval(currentThinkingTimer); currentThinkingTimer = null; }
            const wasAborted = error && (error.name === 'AbortError' || /abort/i.test(error.message || ''));
            currentAbortController = null;
            if (stopButton) { stopButton.style.display = 'none'; }
            if (wasAborted) {
                addMessageToChat('assistant', 'Generation stopped.', { elapsedMs });
                if (generatedNumberEl) {
                    const badge = generatedNumberEl.querySelector('.badge');
                    if (badge) { badge.textContent = 'Generation stopped'; }
                }
            } else {
                addMessageToChat('assistant', 'Error: ' + (error && error.message ? error.message : 'Unknown error'), { elapsedMs });
                if (generatedNumberEl) {
                    const badge = generatedNumberEl.querySelector('.badge');
                    if (badge) { badge.textContent = `Generated in ${elapsedMs ? formatElapsed(elapsedMs) : '—'}`; }
                }
            }
        }
    }

    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    // Stop generation immediately on click
    if (stopButton) {
        stopButton.addEventListener('click', () => {
            try {
                if (currentAbortController) currentAbortController.abort();
            } catch(e) { /* no-op */ }
        });
    }
    
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Suggestions chips (send directly on click, with footer hide)
    if (suggestions) {
        suggestions.addEventListener('click', (e) => {
            const t = e.target;
            // Carousel arrow controls
            if (t && t.classList && t.classList.contains('carousel-arrow')) {
                const carousel = suggestions.querySelector('.footer-carousel');
                if (carousel) {
                    const dir = t.classList.contains('prev') ? -1 : 1;
                    carousel.scrollBy({ left: dir * 240, behavior: 'smooth' });
                }
                return;
            }
            if (t && t.classList && t.classList.contains('suggestion-chip')) {
                // Hide footer on any item click
                hideCopilotFooter();
                // Clear chat action
                if (t.id === 'clear-chat') {
                    chatMessages.innerHTML = '';
                    chatHistory = [];
                    addMessageToChat('assistant', 'Chat cleared. How can I help you next?');
                    return;
                }
                const msg = t.getAttribute('data-msg');
                if (msg) {
                    // Populate input and send immediately
                    userInput.value = msg;
                    adjustInputState();
                    sendMessage();
                }
            }
        });
    }

    // Hide footer on downward scroll of chat messages
    let lastScrollTop = 0;
    if (chatMessages) {
        chatMessages.addEventListener('scroll', () => {
            const st = chatMessages.scrollTop || 0;
            if (st > lastScrollTop + 8) {
                hideCopilotFooter();
            }
            lastScrollTop = st;
        });
    }

    // Attachment: trigger hidden file input and render previews
    if (attachButton && fileInput) {
        attachButton.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', async (e) => {
            const files = Array.from(e.target.files || []);
            if (!files.length) return;
            for (const file of files) {
                try {
                    if (file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = () => {
                            addMessageToChat('user', `Attached ${file.name}`, { images: [reader.result] });
                        };
                        reader.readAsDataURL(file);
                    } else {
                        const info = `${file.name} (${Math.round(file.size/1024)} KB)`;
                        addMessageToChat('user', `Attached file: ${info}`);
                    }
                } catch (err) {
                    addMessageToChat('assistant', 'Attachment error: ' + err.message);
                }
            }
            // reset input so same file can be re-selected
            fileInput.value = '';
        });
    }

    // Voice input via Web Speech API
    if (voiceButton) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (SpeechRecognition) {
            recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false; // avoid interim duplicates
            recognition.maxAlternatives = 1;
            recognition.lang = 'en-US';
            recognition.onresult = (event) => {
                let transcript = '';
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const res = event.results[i];
                    if (res.isFinal && res[0] && res[0].transcript) {
                        transcript += res[0].transcript;
                    }
                }
                if (transcript) {
                    voiceAccumulated += (voiceAccumulated ? ' ' : '') + transcript.trim();
                    userInput.value = (baseInputBeforeVoice ? (baseInputBeforeVoice + ' ') : '') + voiceAccumulated;
                    adjustInputState();
                }
            };
            recognition.onend = () => {
                recognizing = false;
                voiceButton.classList.remove('recording');
                baseInputBeforeVoice = '';
                voiceAccumulated = '';
            };
            recognition.onerror = () => {
                recognizing = false;
                voiceButton.classList.remove('recording');
                baseInputBeforeVoice = '';
                voiceAccumulated = '';
            };
            voiceButton.addEventListener('click', () => {
                if (!recognizing) {
                    try {
                        baseInputBeforeVoice = (userInput.value || '').trim();
                        voiceAccumulated = '';
                        recognition.start();
                        recognizing = true;
                        voiceButton.classList.add('recording');
                    } catch(e) {
                        console.warn('Recognition start failed:', e);
                    }
                } else {
                    try { recognition.stop(); } catch(e) {}
                    recognizing = false;
                    voiceButton.classList.remove('recording');
                    baseInputBeforeVoice = '';
                    voiceAccumulated = '';
                }
            });
        } else {
            voiceButton.addEventListener('click', () => {
                addMessageToChat('assistant', 'Voice input is not supported in this browser.');
            });
        }
    }
    // Initial greeting
     addMessageToChat('assistant', 'Hello! I am Codey the Wizard Designer. How can I help you today?');
});

// Override sendMessage to track last user prompt
// Keep original signature; redefine after DOMContentLoaded scope
function sendMessageWrapper(origSend) {
    return async function() {
        const input = document.getElementById('user-input');
        if (!input) return;
        const message = input.value.trim();
        if (message) {
            lastUserMessage = message;
        }
        return await origSend();
    };
}

// Patch sendMessage reference on window
window.addEventListener('load', () => {
    try {
        // Find the sendMessage function from closure by hooking the button
        const btn = document.getElementById('send-button');
        if (btn) {
            const oldHandler = btn.onclick;
            // If no direct onclick, rely on our wrapper via value tracking in keypress/click
        }
    } catch(e) { /* no-op */ }
});